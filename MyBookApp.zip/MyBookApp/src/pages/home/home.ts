import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { TocPage } from '../toc/toc';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  tocPage = TocPage;

  constructor(public navCtrl: NavController) {

  }

  title = 'KEEP PRESSIN ON'
  caption = 'Join the Magical World of Hard Work and Determination'

}
