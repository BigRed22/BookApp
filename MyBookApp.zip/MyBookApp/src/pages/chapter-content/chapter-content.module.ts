import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChapterContentPage } from './chapter-content';

@NgModule({
  declarations: [
    ChapterContentPage,
  ],
  imports: [
    IonicPageModule.forChild(ChapterContentPage),
  ],
})
export class ChapterContentPageModule {}
