import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Chapter1Page } from '../chapter1/chapter1';
import { Chapter2Page } from '../chapter2/chapter2';
import { TocPage } from '../toc/toc';
/**
 * Generated class for the ChapterContentPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-chapter-content',
  templateUrl: 'chapter-content.html',
})
export class ChapterContentPage {
  chapter1 = Chapter1Page;
  chapter2 = Chapter2Page;
  tocPage = TocPage;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ChapterContentPage');
  }

}
