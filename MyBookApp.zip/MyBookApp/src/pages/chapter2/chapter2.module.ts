import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Chapter2Page } from './chapter2';

@NgModule({
  declarations: [
    Chapter2Page,
  ],
  imports: [
    IonicPageModule.forChild(Chapter2Page),
  ],
})
export class Chapter2PageModule {}
