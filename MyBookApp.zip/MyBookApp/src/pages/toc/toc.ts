import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../home/home';
import { Chapter1Page } from '../chapter1/chapter1';
import { Chapter2Page } from '../chapter2/chapter2';

@IonicPage()
@Component({
  selector: 'page-toc',
  templateUrl: 'toc.html',
})
export class TocPage {
  coverPage = HomePage;
  chapter1 = Chapter1Page;
  chapter2 = Chapter2Page;


  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  header = "Select a Chapter"


  ionViewDidLoad() {
    console.log('ionViewDidLoad TocPage');
  }

}
